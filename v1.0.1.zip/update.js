const path = require('path');
const axios = require('axios');
const { app } = require('electron');
const request = require('superagent');
const decompress = require("decompress");
const fs = require('fs');
var packageJson = require(path.join(__dirname, "package.json"));


axios.get('https://raw.githubusercontent.com/UNDER192103/updateunderdeck/main/underdeckupdate.json')
.then((response) => {
    var data = response.data;
    require('./app.js');
    if(data.version == packageJson.version){

    }
    else{
         request.get(data.url).on('error', function(error) {
            console.log(error);
        })
        .pipe(fs.createWriteStream("file.zip")).on('finish', () => {

            decompress("file.zip", "")
            .then((files) => {
                console.log("Finish")
            })
            .catch((error) => {
              console.log(error);
            });
        });
    }
})
.catch(function (error) {
})
.finally(function (response) {
});
