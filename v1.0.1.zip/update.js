const path = require('path');
var axios = require('axios');
const { app } = require('electron');
var packageJson = require(path.join(__dirname, "package.json"));

axios.get('https://raw.githubusercontent.com/UNDER192103/updateunderdeck/main/underdeckupdate.json')
.then(function (response) {
    var data = response.data
    console.log(data.version)
    console.log(packageJson.version)
    if(data.version == packageJson.version){
        require('./app.js');
    }
    else{
        console.log("Atualizar!")
    }
})
.catch(function (error) {
})
.finally(function (response) {
});
