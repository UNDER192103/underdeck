
const path = require('path');
const { app, BrowserWindow, Menu, MenuItem } = require('electron');
const Jsoning = require("jsoning");

var { _all }  = require(path.join(__dirname, 'service', 'model', 'gtx.js'));
  _all.db = new Jsoning(path.join(__dirname, "src", "data", "db.json"));

function createWindow () {

  const window = new BrowserWindow({
    width: 800,
    height: 600,
    autoHideMenuBar: true,
    icon: path.join(__dirname, 'src', 'img', 'under-icon.ico'),
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      preload: path.join(__dirname, 'service', 'preload.js')
    }
  });

  window.maximize();
  window.loadFile(path.join(__dirname, "app.html"));
}

const menu = new Menu();
menu.append(new MenuItem({
  label: 'Help',
  submenu: [{
    role: 'help',
    accelerator: process.platform === 'darwin' ? 'Ctrl+R' : 'Alt+Shift+I',
    click: () => { console.log('Electron rocks!') }
  }],
}));

Menu.setApplicationMenu(menu);


app.whenReady().then(() => {
  createWindow()

  app.on('activate', function () {

    if (BrowserWindow.getAllWindows().length === 0) createWindow()
  })
})


app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') app.quit()
})
