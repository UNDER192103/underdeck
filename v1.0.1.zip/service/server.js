var { _all }  = require(_dirname+'/service/model/gtx.js');
const express = require('express');
const app = express();
const path = require('path');
_all.db = new Jsoning(_dirname+"/src/data/db.json");
var port = null, server = null, isStarted = false;
var ip = require("ip");

port = _all.db.get('server_port');


async function start_server(type, callback) {
    if(type == true){
        if(isStarted == false){
            app.get('/', (req, res) => {
                res.sendFile(__dirname.replace('service', '')+'src/img/underbot_logo.svg')
            });
        
            server = app.listen(port, `${ip.address()}` || "localhost" , () => {
                console.log(`Start Sucess LocalServer in: ${port}`)
                isStarted = true;
            });

            callback('Star Sucess');
        }
        else{
            callback('Server is Started');
        }
    }
    else{
        if(isStarted == true){
            server.close();
            isStarted = false;
            callback('Stop');
        }
        else{
            //callback('Server Not started');
        }
    }
}

module.exports = {
    start_server
};