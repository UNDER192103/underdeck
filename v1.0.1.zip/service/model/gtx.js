var _all = {
    db: null,
    programsExe: null,
    server_port: null,
    list_macros: null,
    list_defaultPromas: null,
    macro_lis: null,
};

module.exports._all = _all;