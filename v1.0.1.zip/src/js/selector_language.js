const langs = require('./src/system_tray/langs.js');
var _lang = localStorage.getItem('lang_selected'), isOk = false;
selec_lang(localStorage.getItem('lang_selected'));



async function selec_lang(id_lang){
    if(id_lang == null)
        id_lang = langs.en_us.id;
    _lang = id_lang;
    await changeLang(langs[id_lang].dt.list_td);
    $(".icone-selected-lang").attr("src", langs[id_lang].icon);
    $(".text-lang-selected").text(langs[id_lang].name);
    localStorage.setItem('lang_selected', id_lang);
    if(!isOk)
        isOk = true;
    else{
        changeAppsHtml();
        change_list_keys_macros();
    }
}

async function changeLang(list){
    list.forEach(item => {
        $(item.id)[item.type](item.text);
    });
};

function getNameTd(idBusca){
    return langs[_lang].dt.list_td.filter(L => L.id == idBusca)[0].text;
}