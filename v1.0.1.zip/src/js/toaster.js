function warning(text){
    $('.toaster').removeClass('bg-danger').removeClass('bg-success').removeClass('bg-warning');

    var toastElList = [].slice.call(document.querySelectorAll('.toaster'))
    var toastList = toastElList.map(function(toastEl) {
      return new bootstrap.Toast(toastEl);
    });
    toastList.forEach(toast => toast.show());
    
    $('.title-toaster').text(getNameTd(".warning_text"));
    $('.body-toaster').text(text);
    $('.toaster').addClass('bg-warning');
}

function success(text){
    $('.toaster').removeClass('bg-danger').removeClass('bg-success').removeClass('bg-warning');

    var toastElList = [].slice.call(document.querySelectorAll('.toaster'))
    var toastList = toastElList.map(function(toastEl) {
      return new bootstrap.Toast(toastEl);
    });
    toastList.forEach(toast => toast.show());

    $('.title-toaster').text(getNameTd(".warning_text"));
    $('.body-toaster').text(text);
    $('.toaster').addClass('bg-success');
}

function danger(text){
    $('.toaster').removeClass('bg-danger').removeClass('bg-success').removeClass('bg-warning');

    var toastElList = [].slice.call(document.querySelectorAll('.toaster'))
    var toastList = toastElList.map(function(toastEl) {
      return new bootstrap.Toast(toastEl)
    });
    toastList.forEach(toast => toast.show());

    $('.title-toaster').text(getNameTd(".warning_text"));
    $('.body-toaster').text(text);
    $('.toaster').addClass('bg-danger');
}

module.exports = {
    warning,
    success,
    danger
};