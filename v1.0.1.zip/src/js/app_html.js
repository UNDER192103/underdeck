const path = require('path');
const Jsoning = require("jsoning");
const fs = require("fs");
const toaster = require("./src/js/toaster.js");
var keyEvent = require('./service/keyMacros.js');
var localServer = require('./service/server.js');
const { exec } = require('child_process');
var { _all }  = require('./service/model/gtx.js');
_all.db = new Jsoning("./src/data/db.json");
_all.list_macros = new Jsoning("./src/data/macros.json");
_all.programsExe = new Jsoning("./src/data/programsExe.json");
var ip = require("ip");


_all.server_port = _all.db.get('server_port');
_all.list_programs = _all.programsExe.get('list_programs');

changeAppsHtml();

document.getElementById('key-macro').checked = _all.db.get('keyEvent');
$('#port-local-server').val(_all.db.get('server_port'));
$('#local-server-adress-acess-url').val(`http://${ip.address()}:${_all.db.get('server_port')}`);

localServer.start_server(_all.db.get('isStartLocalServer'), (r)=>{
    console.log(r)
});


$(document).ready(function(){
    if(localStorage.getItem('page') != '1' && localStorage.getItem('page') != null)
        selectMenu(parseInt(localStorage.getItem('page')));
        
    $("#btnSelectExe").click(async function(){
        var file = $('#selectExe')[0].files[0];
        await saveExeToExecute(file);
    });

    $('#key-macro').click(function(){
        let isCheck =  document.getElementById('key-macro').checked;
        keyEvent.startStopKeysEvents(isCheck);
        _all.db.set('keyEvent', isCheck);
    });


    $('#btn-port-local-server').click(async function(){
        var port = $('#port-local-server').val();
        if(port.length == 4 && !isNaN(port)){
            $('.alert-por-local-server-modal').addClass('hidden');
            await _all.db.set('server_port', port);
            $('#local-server-adress-acess-url').val(`http://${ip.address()}:${_all.db.get('server_port')}`);
            toaster.success(getNameTd(".s_s_text"))
            if(_all.db.get('isStartLocalServer')){
                setTimeout(()=>{location.reload()}, 700) 
            }
        }
        else{
            $('.alert-por-local-server-modal').text(getNameTd(".t_p_m_c_4_n_text"))
                .removeClass('hidden');
        }
    });

    $('#button-start-local-server').click(async function(){
        if(_all.db.get('isStartLocalServer') == true){
            $('#button-start-local-server').text(getNameTd(".start_text"))
                .removeClass('btn-success')
                .addClass('btn-danger');
            await _all.db.set('isStartLocalServer', false);
            location.reload();
        }
        else{
            $('#button-start-local-server').text(getNameTd(".stop_text")).removeClass('btn-danger').addClass('btn-success');
            _all.db.set('isStartLocalServer', true);
            localServer.start_server(true, (r)=>{
                console.log(r)
            })
        }
    });

    if(_all.db.get('isStartLocalServer') == true)
        $('#button-start-local-server').text(getNameTd(".stop_text"))
            .removeClass('btn-danger')
            .addClass('btn-success');

    else 
        $('#button-start-local-server').text(getNameTd(".start_text"))
            .removeClass('btn-success')
            .addClass('btn-danger');
    
})

async function saveExeToExecute(file){
    if(file != undefined){
        var filesSaved = _all.programsExe.get('list_programs'), isFileSaved = false;
        await filesSaved.forEach(item => {
            if(item.name == file.name)
                isFileSaved = true;
        });
        if(!isFileSaved){
            var _idItem = filesSaved.length+1;
            var item = {_id: _idItem, lastModified: file.lastModified, lastModifiedDate: file.lastModifiedDate, name: file.name, nameCustom: '', path: file.path, type: file.type, size: file.size }
            await _all.programsExe.push("list_programs", item);
            appendHtml(item, _idItem);
            _all.list_programs = await _all.programsExe.get('list_programs');
        }
        else{
            toaster.warning(getNameTd(".t_e_i_a_r_text"));
        }
    }
    else{
        toaster.warning(getNameTd(".p_s_a_e_text"));
    }
}

function appendHtml(item, count){
    var name = item.name.replace('.exe', '');
    var icone = __dirname+"/src/img/underbot_logo.svg";
    if(item.nameCustom.length > 0)
        name = item.nameCustom;
    if(item.iconCustom != null)
        icone = item.iconCustom;
    $('.content-files-add').append(`<div class="col" id="col-exe-id-${count}"><div class="card rounded-3 hover-exes border border-4 rounded bg-dark text-light"><div class="m-2 hover-icon-edit d-flex flex-row-reverse bd-highlight"><a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="bi bi-gear-wide"></i></a><ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDarkDropdownMenuLink">`+
    `<li onClick="startExe(${count})"><a class="dropdown-item" href="#"><i class="bi bi-filetype-exe"></i> ${getNameTd(".start_text")}</a></li>`+
    `<li onClick="editExe(${count})" type="button" data-bs-toggle="modal" data-bs-target="#modal-edit-exe"><a class="dropdown-item" href="#"><i class="bi bi-pen text-success"></i> ${getNameTd(".edit_text")}</a></li>`+
    `<li onClick="deleteExe(${count})"><a class="dropdown-item" href="#"><i class="bi bi-trash3 text-danger"></i> ${getNameTd(".delete_text")}</a></li>`+
    `</ul></div><img src="${icone}" class="card-img-top w-75 mt-3 auto-left-right rounded" alt="..."><hr><div class="card-body"><h5 class="card-title">${name}</h5><a class="hidden" id="col-title-exe-id-${count}">${item.name.replace('.exe', '')}</a><p class="card-text"></p></div></div></div>`)
}

function startExe(id){
    var list_programs = _all.programsExe.get('list_programs');
    var item = list_programs.filter(b => b._id == id)[0];
    if(item.isExe != "browser"){
        exec(`"${item.path}"`, (err, exit, stErr) => {
            console.log(err)
            console.log(exit)
            console.log(stErr)
        });
    }
    else{
        exec(`${item.path}`, (err, exit, stErr) => {
            console.log(err)
            console.log(exit)
            console.log(stErr)
        });
    }
}

var editExeNow = null;

async function deleteExe(id){
    var list_programs = _all.programsExe.get('list_programs');
    var item = list_programs.filter(b => b._id == id)[0]
    if(item.isExe != "browser"){
        _all.programsExe.set('list_programs', list_programs.filter(b => b._id != id));
        let listNowMacro = await _all.list_macros.get('macros');
        let newListMacros = listNowMacro.filter(m => m.idProgram != id);
        await _all.list_macros.set('macros', newListMacros);
        change_list_keys_macros(_all.list_macros.get('macros'));
        $(`#col-exe-id-${id}`).remove();
        if(item.iconCustom != null)
            fs.access(item.iconCustom, fs.constants.F_OK, (err) => {
                if (!err)
                fs.unlinkSync(item.iconCustom)
            });
    }
};

function clearEditExe(){ editExeNow = null};

function openIpUrlWeb(){ exec(`start http://${ip.address()}:${_all.db.get('server_port')}`) };

async function changeAppsHtml(){
    let listApps = await _all.programsExe.get('list_programs');
    $('.content-files-add').html('');
    await listApps.forEach(item => {
        appendHtml(item, item._id);
    });
}

async function getAppById(id){
    if(id != null){
        var list_programs = await _all.programsExe.get('list_programs');
        return list_programs.filter(b => b._id == id)[0];
    }
    else
        return null;
}

async function getNameApp(app){
    var name = app.name.replace('.exe', '');
    if(app.nameCustom.length > 0)
        name = app.nameCustom;
    return name;
}

function editExe(id){
    var list_programs = _all.programsExe.get('list_programs');
    var item = list_programs.filter(b => b._id == id)[0];

    editExeNow = item;
    var name = item.name.replace('.exe', '');
    if(item.nameCustom.length > 0)
        name = item.nameCustom;
    $('#modal-edit-exeLabel').text(`${getNameTd(".edit_text")} ( ${name} )`);
    $('#name-exe-modal').val(name);
};

async function saveEditExe(){
    var file = $('#icon-exe-edit')[0].files[0];
    await saveIconFile(file, async (r)=>{
        var newName = $('#name-exe-modal').val();
        if(newName.length > 0 && newName != editExeNow.nameCustom && newName != editExeNow.name){
            editExeNow.nameCustom = newName;
        }
    
        var list_programs = _all.programsExe.get('list_programs'), newList = new Array();
        await list_programs.forEach(element => {
            if(element.name == editExeNow.name)
                element = editExeNow;
            newList.push(element);
        });
        await _all.programsExe.set('list_programs', newList);
        _all.list_programs = newList;
        await changeAppsHtml();

        if(r){
            fs.access(r, fs.constants.F_OK, (err) => {
                if (!err)
                fs.unlinkSync(r)
            })
        }

        $('.btn-close-exe-modal').click();
    });
};

async function saveIconFile(fileInput, callback){
    if(fileInput){
        var dirCopy = path.join(__dirname, 'src', 'img', 'icons-exe', `${editExeNow.name.replace('.','-')}-${fileInput.name}`);
        const oldFile = editExeNow.iconCustom;
        fs.copyFile(fileInput.path, dirCopy, (err) => {
            if (err) throw err;
            editExeNow['iconCustom'] = dirCopy;
            callback(oldFile);
        })
    }else{
        callback();
    }
};

async function selectMenu(id){
    $(`.container-hide-control`).addClass('hidden');

    for (let index = 1; index < $('.nav-item').length+1; index++) {
        $(`#nav-item-${index}`).removeClass('active').addClass('link-dark');
    }
    $(`#nav-item-${id}`).addClass('active').removeClass('link-dark');

    if(id == 1){
        changeAppsHtml();
        $(`.container-home`).removeClass('hidden');
    }
    else if(id == 2){
        $(`.container-config`).removeClass('hidden');
    }
    else if(id == 3){
        await change_list_keys_macros();
        $(`.container-kys-macros`).removeClass('hidden');
    }
    localStorage.setItem('page', id)
};