var en_us = [
    {
        id: ".menu_text",
        type: "text",
        text: "Menu"
    },
    {
        id: ".open_text",
        type: "text",
        text: "Open"
    },
    {
        id: ".t_a_i_a_r_i_t_l_o_s_text",
        type: "text",
        text: "This application is already registered in the list of shortcuts!"
    },
    {
        id: ".url_text_expc_1",
        type: "text",
        text: "URL:"
    },
    {
        id: ".door_text_expc_1",
        type: "text",
        text: "Door:"
    },
    {
        id: ".cancel_text",
        type: "text",
        text: "Cancel"
    },
    {
        id: ".s_s_text",
        type: "text",
        text: "Saved successfully"
    },
    {
        id: ".t_p_m_c_4_n_text",
        type: "text",
        text: "The port must contain only 4 numbers, Example: 3000!"
    },
    {
        id: ".t_e_i_a_r_text",
        type: "text",
        text: "This executable is already registered!"
    },
    {
        id: ".stop_text",
        type: "text",
        text: "Stop"
    },
    {
        id: ".options_text",
        type: "text",
        text: "Options"
    },
    {
        id: ".macro_text",
        type: "text",
        text: "Shortcut"
    },
    {
        id: ".add_macro_text",
        type: "text",
        text: "Add Shortcut"
    },
    {
        id: ".name_text",
        type: "text",
        text: "Name",
    },
    {
        id: ".name_text_expc_1",
        type: "text",
        text: "Name:",
    },
    {
        id: ".icon_text_expc_1",
        type: "text",
        text: "Icon:",
    },
    {
        id: ".apps_name",
        type: "text",
        text: "Apps",
    },
    {
        id: "#nav-item-2",
        type: "text",
        text: "Settings",
    },
    {
        id: ".keys_macro_text",
        type: "text",
        text: "Hotkeys",
    },
    {
        id: "#nav-item-4",
        type: "text",
        text: "Reload",
    },
    {
        id: ".add_text",
        type: "text",
        text: "Add",
    },
    {
        id: ".close_text",
        type: "text",
        text: "Close",
    },
    {
        id: ".save_text",
        type: "text",
        text: "Save",
    },
    {
        id: ".recording_text",
        type: "text",
        text: "Recording"
    },
    {
        id: ".start_text",
        type: "text",
        text: "Start"
    },
    {
        id: ".edit_text",
        type: "text",
        text: "Edit"
    },
    {
        id: ".delete_text",
        type: "text",
        text: "Delete"
    },
    {
        id: ".shortcut_text",
        type: "text",
        text: "Shortcut"
    },
    {
        id: ".key_macro_text",
        type: "text",
        text: "Hotkeys"
    },
    {
        id: ".web_stream_deck_text",
        type: "text",
        text: "Web Stream Deck"
    },
    {
        id: ".warning_text",
        type: "text",
        text: "Warning"
    },
    {
        id:".p_c_a_s_text",
        type: "text",
        text: "Please configure a shortcut!"
    },
    {
        id:".p_s_a_a_text",
        type: "text",
        text: "Please select an app!"
    },
    {
        id:".p_s_a_e_text",
        type: "text",
        text: "Please select an executable!"
    }
]

module.exports.list_td = en_us;