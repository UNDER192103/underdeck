var pt_br = [
    {
        id: ".menu_text",
        type: "text",
        text: "Menu"
    },
    {
        id: ".t_a_i_a_r_i_t_l_o_s_text",
        type: "text",
        text: "Esté aplicativos já esta cadastrado na lista de atalhos!"
    },
    {
        id: ".open_text",
        type: "text",
        text: "Abrir"
    },
    {
        id: ".url_text_expc_1",
        type: "text",
        text: "LINK:"
    },
    {
        id: ".door_text_expc_1",
        type: "text",
        text: "Porta:"
    },
    {
        id: ".s_s_text",
        type: "text",
        text: "Salvo com sucesso"
    },
    {
        id: ".t_p_m_c_4_n_text",
        type: "text",
        text: "A porta deve conter apenas 4 numeros, Exemplo: 3000!"
    },
    {
        id: ".stop_text",
        type: "text",
        text: "Para"
    },
    {
        id: ".options_text",
        type: "text",
        text: "Opções"
    },
    {
        id: ".macro_text",
        type: "text",
        text: "Atralho"
    },
    {
        id: ".add_macro_text",
        type: "text",
        text: "Adicionar Atalho"
    },
    {
        id: ".name_text",
        type: "text",
        text: "Nome",
    },
    {
        id: ".name_text_expc_1",
        type: "text",
        text: "Nome:",
    },
    {
        id: ".icon_text_expc_1",
        type: "text",
        text: "Icone:",
    },
    {
        id: ".apps_name",
        type: "text",
        text: "Aplicativos",
    },
    {
        id: "#nav-item-2",
        type: "text",
        text: "Configurações",
    },
    {
        id: ".keys_macro_text",
        type: "text",
        text: "Teclas de atalho",
    },
    {
        id: "#nav-item-4",
        type: "text",
        text: "Recarregar",
    },
    {
        id: ".add_text",
        type: "text",
        text: "Adicionar",
    },
    {
        id: ".close_text",
        type: "text",
        text: "Fechar",
    },,
    {
        id: ".save_text",
        type: "text",
        text: "Salvar",
    },
    {
        id: ".recording_text",
        type: "text",
        text: "Gravando"
    },
    {
        id: ".t_e_i_a_r_text",
        type: "text",
        text: "Esté executavel já está cadastrado!"
    },
    {
        id: ".start_text",
        type: "text",
        text: "Iniciar"
    },
    {
        id: ".cancel_text",
        type: "text",
        text: "Cancelar"
    },
    {
        id: ".edit_text",
        type: "text",
        text: "Editar"
    },
    {
        id: ".delete_text",
        type: "text",
        text: "Excluir"
    },
    {
        id: ".shortcut_text",
        type: "text",
        text: "Atalho"
    },
    {
        id: ".key_macro_text",
        type: "text",
        text: "Teclas de atalho"
    },
    {
        id: ".web_stream_deck_text",
        type: "text",
        text: "Web Stream Deck"
    },
    {
        id: ".warning_text",
        type: "text",
        text: "Aviso"
    },
    {
        id:".p_c_a_s_text",
        type: "text",
        text: "Por favor, configure um atalho!"
    },
    {
        id:".p_s_a_a_text",
        type: "text",
        text: "Por favor, selecione um aplicativo!"
    },
    {
        id:".p_s_a_e_text",
        type: "text",
        text: "Por favor selecione um executavel!"
    }
];

module.exports.list_td = pt_br;