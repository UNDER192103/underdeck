const path = require('path');
const axios = require('axios');
const { app } = require('electron');
const request = require('superagent');
const decompress = require("decompress");
const fs = require('fs');
const fsPromises = require('fs').promises;
var packageJson = require(path.join(__dirname, "package.json"));

if (fs.existsSync(path.join(__dirname, 'update.zip'))){
    fs.rmSync(path.join(__dirname, 'update.zip'), { recursive: true, force: true });
}

if (fs.existsSync(path.join(__dirname, 'updatedir'))){
    fs.rmSync(path.join(__dirname, 'updatedir'), { recursive: true, force: true });
}

axios.get('https://raw.githubusercontent.com/UNDER192103/updater_undeck/main/version.json')
.then((response) => {
    var data = response.data;
    if(data.version == ""+packageJson.version+""){
        require("./App/app.js");
    }
    else{
         request.get(data.url).on('error', function(error) {
            console.log(error);
        })
        .pipe(fs.createWriteStream("update.zip")).on('finish', () => {

            decompress("update.zip", __dirname+"\\updatedir")
            .then(async (files) => {
                await get_and_overwrite_files(__dirname+"\\updatedir",async (res)=>{
                    if (fs.existsSync(path.join(__dirname, 'update.zip'))){
                        await fs.rmSync(path.join(__dirname, 'update.zip'), { recursive: true, force: true });
                    }
                    
                    if (fs.existsSync(path.join(__dirname, 'updatedir'))){
                        await fs.rmSync(path.join(__dirname, 'updatedir'), { recursive: true, force: true });
                    }
                    app.relaunch();
                    app.exit();
                });
            })
            .catch((error) => {
              console.log(error);
            });

        });
    }
    
}).catch((error) => { }).finally((response) => { });

async function get_and_overwrite_files(dirUpdate, callback){
    let allFilesUpdate = await listAllFilesInFolder(dirUpdate);
    for (let CONF = 0; CONF < allFilesUpdate.length; CONF++) {
        const FILE = allFilesUpdate[CONF];
        const OVERFILE = await FILE.replace('\\updatedir', '');
        var dataFile = await fs.readFileSync(FILE);
        await fs.writeFileSync(OVERFILE, dataFile, (r)=>{});
        if(CONF >= (allFilesUpdate.length-1)){
            callback(true);
        }
    }
}


async function listAllFilesInFolder(diretorio, arquivos) {

    if(!arquivos)
        arquivos = [];

    let listaDeArquivos = await fsPromises.readdir(diretorio);
    for(let k in listaDeArquivos) {
        let stat = await fsPromises.stat(diretorio + '\\' + listaDeArquivos[k]);
        if(stat.isDirectory())
            await listAllFilesInFolder(diretorio + '\\' + listaDeArquivos[k], arquivos);
        else
            arquivos.push(diretorio + '\\' + listaDeArquivos[k]);
    }

    return arquivos;

}
