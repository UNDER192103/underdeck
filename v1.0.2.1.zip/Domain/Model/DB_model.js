module.exports = {
    DB: null,
    Opens_windows: null,
    ProgramsExe: null,
    Server_port: null,
    List_macros: null,
    List_programs: null,
    List_defaultPromas: null,
    Macro_lis: null,
    Selected_port_com: null,
    GetDataNow: null,
};